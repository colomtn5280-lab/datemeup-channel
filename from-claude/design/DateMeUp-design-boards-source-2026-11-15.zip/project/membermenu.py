"""Member menu: Remove from group / Leave group (decided 2026-11-15). Writes M12b board + updates M12 + notes."""
import json, os, re
P = '/home/claude/vid/canvas/project'
src = open(f'{P}/M12_MemberMenu.dc.html').read()
helmet = src[src.index('<helmet>'):src.index('</helmet>') + len('</helmet>')]

def save(path, text):
    with open(path + '.tmp', 'w') as fh: fh.write(text)
    os.replace(path + '.tmp', path)

ICON = {
 'flag': '<path d="M5 21 V4 M5 4 h11 l-2 4 l2 4 H5"></path>',
 'block': '<circle cx="12" cy="12" r="8.5"></circle><path d="M6 6 L18 18"></path>',
 'remove': '<circle cx="9" cy="8" r="3.5"></circle><path d="M3 20 a6 6 0 0 1 12 0"></path><path d="M16 11 h6"></path>',
 'leave': '<path d="M14 4 H6 a1 1 0 0 0 -1 1 V19 a1 1 0 0 0 1 1 H14"></path><path d="M11 12 H21 M17 8 l4 4 l-4 4"></path>',
 'crown': '<path d="M4 18 L3 8 l5 4 l4 -6 l4 6 l5 -4 l-1 10 Z"></path>',
}
def ic(k): return f'<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">{ICON[k]}</svg>'
def row(k, label, color='#1E1A38', last=False):
    b = 'border: 0' if last else 'border-left: 0; border-right: 0; border-top: 0'
    return f'<button type="button" class="row" style="width: 100%; {b}; background: transparent; font: 500 15px Inter, sans-serif; color: {color}">{ic(k)}{label}</button>'
def head(init, bg, name, sub, hid):
    return (f'<div style="display: flex; align-items: center; gap: 12px"><span class="av" style="width: 44px; height: 44px; background: {bg}; font-size: 13px">{init}</span>'
            f'<div><div id="{hid}" class="h3">{name}</div><div class="sm mut">{sub}</div></div></div>')
bgpage = '<div class="pad" style="opacity: .4"><h1 class="h1">Trio Date Club</h1><div style="height: 300px"></div></div><div class="scrim"></div>'
def phone(cap, inner):
    return (f'<figure style="margin: 0; display: flex; flex-direction: column; gap: 10px"><figcaption class="cap mut">{cap}</figcaption>'
            f'<div class="scr">{bgpage}{inner}</div></figure>')

# A: owner taps another member
A = phone('1 · Owner taps a member', f'''<section class="sheet" role="dialog" aria-modal="true" aria-labelledby="a1">
  <div class="grab"></div>{head("SM", "#D6F0EE", "Sam M.", "Member · joined Nov 12", "a1")}
  <div class="card">{row("remove", "Remove from group")}{row("flag", "Report Sam M.")}{row("block", "Block Sam M.", "#B3261E", True)}</div>
  <button type="button" class="btn">Cancel</button></section>''')

# B: anyone taps their own row
B = phone('2 · You tap your own row', f'''<section class="sheet" role="dialog" aria-modal="true" aria-labelledby="b1">
  <div class="grab"></div>{head("GR", "#FDEFD3", "G R (you)", "Owner · joined Nov 15", "b1")}
  <div class="card">{row("crown", "Make someone else owner")}{row("leave", "Leave group", "#B3261E", True)}</div>
  <p class="p sm" style="margin: 0">You're the only owner. Pick a new owner first, or the member who's been here longest takes over when you leave.</p>
  <button type="button" class="btn">Cancel</button></section>''')

# C: confirm remove
C = phone('3 · Confirm (remove)', f'''<section class="sheet" role="alertdialog" aria-modal="true" aria-labelledby="c1" aria-describedby="c2">
  <div class="grab"></div><h2 id="c1" class="h2">Remove Sam from Trio Date Club?</h2>
  <p id="c2" class="p">Sam stops seeing this group's plans and votes. Their past votes stay counted. You can invite them back any time.</p>
  <button type="button" class="btn" style="background: #B3261E; border-color: #B3261E; color: #fff">Remove Sam</button>
  <button type="button" class="btn">Cancel</button></section>''')

# D: confirm leave (member, not sole owner)
D = phone('4 · Confirm (leave)', f'''<section class="sheet" role="alertdialog" aria-modal="true" aria-labelledby="d1" aria-describedby="d2">
  <div class="grab"></div><h2 id="d1" class="h2">Leave Trio Date Club?</h2>
  <p id="d2" class="p">You'll stop getting its plans and notifications. Your past votes stay counted. Someone in the group can invite you back.</p>
  <button type="button" class="btn" style="background: #B3261E; border-color: #B3261E; color: #fff">Leave group</button>
  <button type="button" class="btn">Cancel</button></section>''')

# E: web — group page members list menu + dialog
E = f'''<figure style="margin: 0; display: flex; flex-direction: column; gap: 10px"><figcaption class="cap mut">5 · Web, group page (same actions)</figcaption>
<div style="width: 560px; height: 844px; box-sizing: border-box; background: #F5F6FA; font-family: Inter, sans-serif; position: relative; padding: 28px; overflow: hidden">
  <div class="card" style="padding: 8px 0">
    <div class="lbl mut" style="padding: 8px 16px">Members · 3</div>
    <div class="row"><span class="av" style="background: #FDEFD3">GR</span>G R (you)<span class="tag" style="margin-left: 6px">Owner</span><span style="flex: 1"></span><button class="ib" aria-label="Actions for G R" style="width: 40px; height: 40px">⋯</button></div>
    <div class="row" style="position: relative"><span class="av" style="background: #D6F0EE">SM</span>Sam M.<span style="flex: 1"></span><button class="ib" aria-label="Actions for Sam M." aria-expanded="true" style="width: 40px; height: 40px; background: #1E1A38; color: #fff">⋯</button>
      <div class="card" role="menu" style="position: absolute; right: 14px; top: 50px; width: 240px; z-index: 2; box-shadow: 0 8px 0 -2px #1E1A38">{row("remove", "Remove from group")}{row("flag", "Report Sam M.")}{row("block", "Block Sam M.", "#B3261E", True)}</div></div>
    <div class="row"><span class="av" style="background: #EAE4FB">JK</span>Jake<span style="flex: 1"></span><button class="ib" aria-label="Actions for Jake" style="width: 40px; height: 40px">⋯</button></div>
  </div>
  <div style="height: 210px"></div>
  <div class="card" style="padding: 14px 16px; display: flex; align-items: center; gap: 12px"><div style="flex: 1"><div class="h3">Leave this group</div><div class="sm mut">In group settings, for every member</div></div><button class="btn danger sm">Leave group</button></div>
  <p class="p sm" style="margin-top: 14px">Confirmations use the same words as mobile, in a centred dialog (Esc and Cancel close it; focus starts on Cancel).</p>
</div></figure>'''

body = f'<div style="display: flex; gap: 40px; align-items: flex-start; padding: 0; background: transparent">{A}{B}{C}{D}{E}</div>'
W, H = 390 * 4 + 560 + 40 * 4, 880
doc = (f'<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<title>Member menu · remove & leave</title>\n<script src="./support.js"></script>\n</head>\n<body>\n<x-dc>\n{helmet}\n{body}\n</x-dc>\n'
       f'<script type="text/x-dc" data-dc-script data-props=\'{{"$preview": {{"width": {W}, "height": {H}}}}}\'>\nclass Component extends DCLogic {{\n  renderVals() {{\n    return {{}};\n  }}\n}}\n</script>\n</body>\n</html>\n')
save(f'{P}/M12b_MemberActions.dc.html', doc)

c = json.load(open(f'{P}/canvas.json'))
c['boards']['M12b_MemberActions.dc.html'] = {'x': 0, 'y': 22300, 'w': W, 'h': H, 'title': 'Member menu · remove & leave (decided)', 'page': 'screens'}
if 'M12b_MemberActions.dc.html' not in c['order']:
    c['order'].insert(c['order'].index('M12_MemberMenu.dc.html') + 1, 'M12b_MemberActions.dc.html')
c['notes']['memberTitle'] = {'x': 0, 'y': 22180, 'text': 'Member menu: Remove from group & Leave group (decided Nov 15)', 'kind': 'title1', 'maxW': W, 'page': 'screens'}
c['notes']['p_M12b_MemberActions'] = {'x': 0, 'y': 23230, 'w': 900, 'size': 's', 'page': 'screens', 'text':
  'RULES · Member actions (NEW, decided Nov 15)\n'
  '• Owner taps another member → Remove from group · Report · Block (Remove only shown to owners)\n'
  '• Member taps another member → Report · Block (unchanged)\n'
  '• Anyone taps their own row → Leave group. Also in group settings (web + mobile).\n'
  '• Sole owner leaving → is asked to pick a new owner first ("Make someone else owner"); if they leave without picking, ownership passes to the longest-standing member. Last member leaving → group is archived.\n'
  '• Both actions confirm on a second sheet with plain consequences; destructive button red, Cancel always present.\n'
  '• After remove/leave: their past votes still count; they lose access to plans, chat and notifications; can be re-invited. Removed person is NOT notified by push (they just lose the group); an in-app line appears in group activity: "G R removed Sam" / "Sam left".\n'
  '• Server enforces: only owners may remove; owners cannot remove themselves (use Leave).'}
n = c['notes']['p_M12_MemberMenu']
n['text'] = n['text'].replace('Product gap (not added here): no "Remove from group" (owner) or "Leave group". Decide with Hermes.',
                              'DECIDED Nov 15: owners get "Remove from group"; everyone gets "Leave group" on their own row. See board M12b.')
s = json.dumps(c, indent=1, ensure_ascii=False)
save(f'{P}/canvas.json', s)
print('ok', W, H)
